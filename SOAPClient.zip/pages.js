// pages.js
{ // dojo requires
    dojo.require('dojox.grid.DataGrid');
    dojo.require('dojox.grid.cells');
    dojo.require("dojo.data.ObjectStore");
    dojo.require("dojo.store.Memory");
    dojo.require("dojo.data.ItemFileWriteStore");
    dojo.require("dojox.xml.parser");
    dojo.require("dojo.parser");
    dojo.require("dijit.layout.ContentPane");
    dojo.require("dijit.layout.BorderContainer");
    dojo.require("dojox.data.CsvStore");
}

var grid;

function setup_dataflow_grid() {
    grid = new dojox.grid.DataGrid({
        structure: [
            {name: "Constraint", field: "constraint", width: "20%"},
            {name: "Code List", field: "component", width: "20%"},
            {name: "Value", field: "value", width: "20%"},
            {name: "And", field: "qAnd", editable: true, cellType: dojox.grid.cells.Bool, width: "10%"},
            {name: "Or", field: "qOr", editable: true, cellType: dojox.grid.cells.Bool, width: "10%"}
        ]
    }, "grid"
            );
    grid.startup();
    // setup the tool tips by reading the code lists from the key family
    var showTooltip = function(e) {
        //console.log("showTooltip");
        var msg;
        if (e.rowIndex >= 0) { // header is <0
            if (e.cell.field == 'value') {
                // value column of constraints
                var item = e.grid.getItem(e.rowIndex);
                var code = e.grid.store.getValue(item, e.cell.field);
                var concept = item.component[0];
                var codelist;

                for (z in e.grid.keyFamilyData.dimensions) {
                    // find the concept map to the code list
                    if (concept == e.grid.keyFamilyData.dimensions[z].concept) {
                        codelist = e.grid.keyFamilyData.dimensions[z].codelist;
                        break;
                    }
                }

                if (codelist) {
                    // find the text in the keyFamilyData
                    var codeLists = e.grid.keyFamilyData.codeLists;
                    for (z in codeLists) {
                        //find right code list
                        if (codeLists[z].code == codelist) {
                            //find code in codelist
                            for (c in codeLists[z].codes) {
                                if (codeLists[z].codes[c].code == code) {
                                    msg = '{0} - {1}'.format(codeLists[z].name, codeLists[z].codes[c].description);
                                    break;
                                }
                            }
                        }
                        if (msg) {
                            break;
                        }
                    }
                }
            }
        }
        ;
        if (msg) {
            //console.log(msg);
            dijit.showTooltip(msg, e.cellNode);
            //dijit.showTooltip(msg, e.cellNode, ["below", "above", "after", "before"]);
        }
    };
    var hideTooltip = function(e) {
        dijit.hideTooltip(e.cellNode);
    };
    dojo.connect(grid, "onCellMouseOver", showTooltip);
    dojo.connect(grid, "onCellMouseOut", hideTooltip);
    dojo.connect(grid, "onHeaderCellMouseOver", showTooltip);
    dojo.connect(grid, "onHeaderCellMouseOut", hideTooltip);
    // grid is the dijit
}

function build_dataset_query(grid) {
    // build a query object to submit to the query builder from the selections in the dataset grid
    var query = {};

    query.qAnd = [];
    query.qOr = [];
    query.startTime = '';
    query.endTime = '';
    query.dataSetId = dojo.byId('objectid').value;

    // go through constraints finding all checked and the start and end time.
    // first the AND
    // then time
    // following dataflow id
    // and finally all the OR things

    var store = grid.store;
    // Returns query results from the array that match the given query

    function gotItemsAnd(items, request) {
        var i;
        for (i = 0; i < items.length; i++) {
            var item = items[i];
            query.qAnd.push({component: store.getValue(item, "component"), value: store.getValue(item, "value")});
        }
    }
    ;

    function gotItemsOr(items, request) {
        var i;
        if (items.length > 0) {
            for (i = 0; i < items.length; i++) {
                var item = items[i];
                query.qOr.push({component: store.getValue(item, "component"), value: store.getValue(item, "value")});
            }
        }
    }
    ;

    store.fetch({query: {qAnd: true}, onComplete: gotItemsAnd});

    var ds, de;

    ds = dijit.byId('StartTime').get('value');
    de = dijit.byId('EndTime').get('value');
    if (ds && de)
    {
        query.startTime = dojo.date.locale.format(ds, {datePattern: 'yyyy-MM-dd', selector: "date"});
        query.endTime = dojo.date.locale.format(de, {datePattern: 'yyyy-MM-dd', selector: "date"});
    }
    store.fetch({query: {qOr: true}, onComplete: gotItemsOr});
    return query;
}

function dataset_query(methodOptions) {
    // build query and send to the queryResult page to be charted.
    var query = build_dataset_query(grid);
    var options = {};
    var encoded = encodeURIComponent(JSON.stringify(query));
    var title = encodeURIComponent(JSON.stringify(dojo.byId('dataFlowTitle').innerHTML));
    var breakField = encodeURIComponent(dijit.byId('breakField').get('value'));

    options.perCapita = dojo.byId('perCapita').checked;
    options = encodeURIComponent(JSON.stringify(options));

    if (methodOptions && methodOptions.map) {
        window.open('{3}?mapResult.html?title={0}?query={1}?options={2}?break={4}'.format(title, encoded, options, getRpage(), breakField), '_blank');
    }
    else {
        window.open('{3}?queryResult.html?title={0}?query={1}?options={2}?break={4}'.format(title, encoded, options, getRpage(), breakField), '_blank');
    }
}

function getDataflowResponse(xmlhttp) {
    // processes the XML for all the dataflow schemes
    dojo.byId("status").innerHTML = "Formatting results...";

    var div = dojo.byId('results');

    div.innerHTML = '';
    var s = '';
    var contentHandler = new DefaultHandler2();
    var id = '';
    var currentName = '';
    var foundCount = 0;
    var elements = Array();
    var data = [];
    var keyFamilyId = '';
    var breakValues = [];

    /*
     <?xml version='1.0' encoding='UTF-8'?>
     <S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">
     <S:Body>
     <ns3:GetDataflowResponse xmlns:ns2="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/query" xmlns:ns3="http://webservices.sdw.ecb/" xmlns:ns4="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/message" xmlns:ns5="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/metadatareport" xmlns:ns6="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/cross" xmlns:ns7="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/genericmetadata" xmlns:ns8="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/common" xmlns:ns9="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/generic" xmlns:ns10="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/compact" xmlns:ns11="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/utility" xmlns:ns12="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/structure" xmlns:ns13="http://www.SDMX.org/resources/SDMXML/schemas/v2_0/registry">
     <out>
     <ns4:Structure>
     <ns4:Header>
     <ns4:ID>d0ab0d52-5eb0-4bb3-b6eb-921ebbc96133</ns4:ID>
     <ns4:Test>false</ns4:Test>
     <ns4:Prepared>2013-02-21T01:21:33+01:00</ns4:Prepared>
     <ns4:Sender id="ECB">
     <ns4:Name>European Central Bank</ns4:Name>
     <ns4:Contact>
     <ns4:Email>statistics@ecb.europa.eu</ns4:Email>
     </ns4:Contact>
     </ns4:Sender>
     </ns4:Header>
     <ns4:Dataflows>
     <ns12:Dataflow isFinal="true" agencyID="ECB" version="1.0" id="2136672">
     <ns12:Name>Financial market data - Key ECB interest rates</ns12:Name>
     <ns12:KeyFamilyRef>
     <ns12:KeyFamilyID>ECB_FMD2</ns12:KeyFamilyID>
     <ns12:KeyFamilyAgencyID>ECB</ns12:KeyFamilyAgencyID>
     <ns12:Version>1.0</ns12:Version>
     </ns12:KeyFamilyRef>
     <ns12:CategoryRef>
     <ns12:CategorySchemeID>SDW_ECONOMIC_CONCEPTS</ns12:CategorySchemeID>
     <ns12:CategorySchemeAgencyID>ECB</ns12:CategorySchemeAgencyID>
     <ns12:CategorySchemeVersion>1.0</ns12:CategorySchemeVersion>
     <ns12:ID>2018801</ns12:ID>
     </ns12:CategoryID>
     </ns12:CategoryRef>
     <ns12:Constraint ConstraintType="Content">
     <ns8:ConstraintID>ECB_FMD2-CONSTRAINT</ns8:ConstraintID>
     <ns8:CubeRegion isIncluded="true">
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>FREQ</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>B</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>REF_AREA</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>U2</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>CURRENCY</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>EUR</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>PROVIDER_FM</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>4F</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>INSTRUMENT_FM</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>KR</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>PROVIDER_FM_ID</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>DFR</ns8:Value>
     </ns8:MemberValue>
     <ns8:MemberValue>
     <ns8:Value>MLFR</ns8:Value>
     </ns8:MemberValue>
     <ns8:MemberValue>
     <ns8:Value>MRR_FR</ns8:Value>
     </ns8:MemberValue>
     <ns8:MemberValue>
     <ns8:Value>MRR_MBR</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     <ns8:Member isIncluded="true">
     <ns8:ComponentRef>DATA_TYPE_FM</ns8:ComponentRef>
     <ns8:MemberValue>
     <ns8:Value>CHG</ns8:Value>
     </ns8:MemberValue>
     <ns8:MemberValue>
     <ns8:Value>LEV</ns8:Value>
     </ns8:MemberValue>
     </ns8:Member>
     </ns8:CubeRegion>
     </ns12:Constraint>
     </ns12:Dataflow>
     </ns4:Dataflows>
     </ns4:Structure>
     </out>
     </ns3:GetDataflowResponse>
     </S:Body>
     </S:Envelope>
     */
    var codeList = '', constaint = '';

    var saxParser = XMLReaderFactory.createXMLReader();
    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        elements.push(localName);

        switch (localName) {
            case 'Dataflow':
                id = atts.getValue(atts.getIndex('id'));
                break;
            case 'KeyFamilyRef':
                s += 'Key family reference';
                break;

        }
    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        var leavingElement = elements.pop();
        switch (localName) {
            case 'Dataflow':
                foundCount++;
                break;
            case 'KeyFamilyRef':
                break;
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
        switch (currentName) {
            case 'Name':
                dojo.byId('dataFlowTitle').innerHTML = '{0} {1}'.format(id, ch);
                break;
            case'KeyFamilyID':
                keyFamilyId = ch;
                s += '&nbsp;<a href="{0}?KeyFamily.html?objectid={1}">{1}</a> '.format(getRpage(), ch);
                break;
            case 'ConstraintID':
                constraint = ch;
                break;
            case 'CategorySchemeID':
                s += '<strong>{0}</strong>'.format(ch);
                break;
            case 'ComponentRef':
                if (elements.indexOf('Constraint') > -1)
                    codeList = ch;
                break;
            case 'Value':
                if (elements.indexOf('Member') > -1 && elements.indexOf('MemberValue') > -1) {
                    data.push({constraint: constraint, component: codeList, value: ch, qAnd: false, qOr: false});
                    if (breakValues.indexOf(codeList) == -1) {
                        // add all unique values to be used as the break values for
                        // determining chart series
                        breakValues.push(codeList);
                    }
                }
                break;
        }
    };
    try {

        saxParser.setHandler(contentHandler);
        saxParser.parseString(xmlhttp.responseText);

    } catch (e) {
        alert('problem processing response:' + e.message);
        dojo.style(dojo.byId('content'), "display", "block");
        dojo.byId('content').focus();
        return;
    }

    if (foundCount == 0)
        s = '<p>No results found</p>';
    // http://dojo-toolkit.33424.n3.nabble.com/how-to-change-ItemFileWriteStore-data-or-dojox-grid-DataGrid-td2353208.html
    var store = new dojo.data.ItemFileWriteStore({data: {items: data}});
    grid.setStore(store);
    var keyFamilyData = getKeyfamily(keyFamilyId);
    grid.keyFamilyData = keyFamilyData;
    //console.log( s );
    div.innerHTML = s;
    var storeValues = [];
    for (z in breakValues) {
        storeValues.push({label: breakValues[z], id: breakValues[z]});
    }
    var breakStore = new dojo.store.Memory({
        data: storeValues
    });

    var defaultBreakField = breakValues.indexOf("REF_AREA") >= 0 ? "REF_AREA" : breakValues[0];
    var select = new dijit.form.Select({
        id: "breakField",
        label: defaultBreakField,
        value: defaultBreakField,
        store: new dojo.data.ObjectStore({objectStore: breakStore}),
        searchAttr: "name"
    }, "breakField");
    select.startup();
    dojo.byId("status").innerHTML = "Done";
}

function _parseKeyFamilyResponse(xmlhttp) {
    // processes the XML for all the category schemes
    // returns a keyFamily JASON object
    var contentHandler = new DefaultHandler2();
    var id = '';
    var currentName = '';
    var foundCount = 0;
    var elements = Array();
    var data = {};
    var codeList; // the current code list

    // format of key families
    data.name = '';
    data.dimensions = [];
    data.timeDimension = '';
    data.primaryMeasure = '';
    data.codeLists = [];
    /*
     <ns4:Header>
     <ns4:ID>6ec8793c-a1e2-405b-b822-0545b5788590</ns4:ID>
     <ns4:Test>false</ns4:Test>
     <ns4:Prepared>2013-03-08T00:22:45+01:00</ns4:Prepared>
     <ns4:Sender id="ECB">
     <ns4:Name>European Central Bank</ns4:Name>
     <ns4:Contact>
     <ns4:Email>statistics@ecb.europa.eu</ns4:Email>
     </ns4:Contact>
     </ns4:Sender>
     </ns4:Header>
     <ns4:CodeLists>
     ....
     <ns12:CodeList isFinal="true" version="1.0" agencyID="ECB" id="CL_AREA_EE">
     <ns12:Name>Area code list</ns12:Name>
     <ns12:Code value="1A">
     <ns12:Description>International organisations</ns12:Description>
     </ns12:Code>
     <ns12:Code value="1B">
     <ns12:Description>UN organisations</ns12:Description>
     </ns12:Code>
     .....

     <ns4:Concepts>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_DENOM">
     <ns12:Name>BKN denomination breakdown</ns12:Name>
     </ns12:Concept>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_ITEM">
     <ns12:Name>Banknote &amp; coin related items</ns12:Name>
     </ns12:Concept>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_SERIES">
     ......
     </ns4:Concepts>

     what is this stuff?

     <ns4:KeyFamilies>
     <ns12:KeyFamily isFinal="true" urn="urn:sdmx:org.sdmx.infomodel.keyfamily.KeyFamily=ECB:ECB_FMD2" version="1.0" agencyID="ECB" id="ECB_FMD2">
     <ns12:Name>Financial market data (not related to foreign exchange)</ns12:Name>
     <ns12:Components>
     <ns12:Dimension isFrequencyDimension="true" codelistAgency="ECB" codelist="CL_FREQ" conceptAgency="ECB" conceptVersion="1.0" conceptRef="FREQ"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_AREA_EE" conceptAgency="ECB" conceptVersion="1.0" conceptRef="REF_AREA"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_CURRENCY" conceptAgency="ECB" conceptVersion="1.0" conceptRef="CURRENCY"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_PROVIDER_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="PROVIDER_FM"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_INSTRUMENT_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="INSTRUMENT_FM"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_PROVIDER_FM_ID" conceptAgency="ECB" conceptVersion="1.0" conceptRef="PROVIDER_FM_ID"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_DATA_TYPE_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="DATA_TYPE_FM"/>

     */
    var hiddenClass = '';

    data.codeLists = []; // array of code lists


    var saxParser = XMLReaderFactory.createXMLReader();
    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        elements.push(localName);

        switch (localName) {
            case 'CodeList':
                codeList = {};
                codeList.code = atts.getValue(atts.getIndex('id'));
                codeList.name = '';
                codeList.codes = [];
                data.codeLists.push(codeList);
                break;
            case 'Code':
                id = atts.getValue(atts.getIndex('value'));
                break;
            case 'Dimension':
                //  <ns12:Dimension isFrequencyDimension="true" codelistAgency="ECB"
                // codelist="CL_FREQ" conceptAgency="ECB" conceptVersion="1.0" conceptRef="FREQ"/>
                data.dimensions.push(
                        {codelist: atts.getValue(atts.getIndex('codelist')), concept: atts.getValue(atts.getIndex('conceptRef'))}
                );
                break;
            case 'PrimaryMeasure':
                //  <ns12:PrimaryMeasure conceptAgency="ECB" conceptVersion="1.0" conceptRef="OBS_VALUE"/>
                data.primaryMeasure = atts.getValue(atts.getIndex('conceptRef'));
                break;
            case 'TimeDimension':
                // <ns12:TimeDimension conceptAgency="ECB" conceptVersion="1.0" conceptRef="TIME_PERIOD"/>
                data.timeDimension = atts.getValue(atts.getIndex('conceptRef'));
                break;
        }

    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        var leavingElement = elements.pop();
        switch (localName) {
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
        switch (currentName) {
            case 'Name':
                if (elements.indexOf('CodeList') > -1) {
                    // long name of the code list
                    codeList.name = ch;
                }
                break;
                if (elements.indexOf('KeyFamily') == elements.length - 2) {
                    // long name of the code list
                    data.name = ch;
                }
                break;
            case 'Description':
                codeList.codes.push({code: id, description: ch});
                break;
        }
    };

    saxParser.setHandler(contentHandler);
    saxParser.parseString(xmlhttp.responseText);

    return data;
}

function getKeyfamily(id) {
    var localStorageKey = 'GetKeyfamily {0}'.format(id);

    // see if the code list is already in local storage
    var v = recallJSON(localStorageKey);
    if (v) {
        return v;
    }

    var soap = '<in><quer:KeyFamily>{0}</quer:KeyFamily><quer:AgencyID>ECB</quer:AgencyID></in>'.format(id);
    var xmlhttp = call_ecb_sdmx_ws_sync(soap, 'GetKeyFamily');

    var data = _parseKeyFamilyResponse(xmlhttp);
    storeJSON(localStorageKey, data);
    return data;
}

function call_dataflow_ws() {
    dojo.byId('content').value = '';

    var dataflowid = dojo.byId('objectid').value;
    var soap = '<in><quer:AgencyID>ECB</quer:AgencyID><quer:ID>' + dataflowid + '</quer:ID></in>';

    call_ecb_sdmx_ws(soap, 'GetDataflow', 'content', getDataflowResponse);
}

function getKeyFamilyResponse(xmlhttp) {
    // processes the XML for all the category schemes
    dojo.byId("status").innerHTML = "Formatting results...";

    var div = dojo.byId('results');

    div.innerHTML = '';
    var s = '';
    var contentHandler = new DefaultHandler2();
    var id = '';
    var currentName = '';
    var foundCount = 0;
    var elements = Array();

    /*
     <ns4:CodeLists>
     <ns12:CodeList isFinal="true" version="1.0" agencyID="ECB" id="CL_AREA_EE">
     <ns12:Name>Area code list</ns12:Name>
     <ns12:Code value="1A">
     <ns12:Description>International organisations</ns12:Description>
     </ns12:Code>
     <ns12:Code value="1B">
     <ns12:Description>UN organisations</ns12:Description>
     </ns12:Code>
     .....

     <ns4:Concepts>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_DENOM">
     <ns12:Name>BKN denomination breakdown</ns12:Name>
     </ns12:Concept>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_ITEM">
     <ns12:Name>Banknote &amp; coin related items</ns12:Name>
     </ns12:Concept>
     <ns12:Concept version="1.0" agencyID="ECB" id="BKN_SERIES">
     ......
     </ns4:Concepts>

     what is this stuff?

     <ns4:KeyFamilies>
     <ns12:KeyFamily isFinal="true" urn="urn:sdmx:org.sdmx.infomodel.keyfamily.KeyFamily=ECB:ECB_FMD2" version="1.0" agencyID="ECB" id="ECB_FMD2">
     <ns12:Name>Financial market data (not related to foreign exchange)</ns12:Name>
     <ns12:Components>
     <ns12:Dimension isFrequencyDimension="true" codelistAgency="ECB" codelist="CL_FREQ" conceptAgency="ECB" conceptVersion="1.0" conceptRef="FREQ"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_AREA_EE" conceptAgency="ECB" conceptVersion="1.0" conceptRef="REF_AREA"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_CURRENCY" conceptAgency="ECB" conceptVersion="1.0" conceptRef="CURRENCY"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_PROVIDER_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="PROVIDER_FM"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_INSTRUMENT_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="INSTRUMENT_FM"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_PROVIDER_FM_ID" conceptAgency="ECB" conceptVersion="1.0" conceptRef="PROVIDER_FM_ID"/>
     <ns12:Dimension codelistAgency="ECB" codelist="CL_DATA_TYPE_FM" conceptAgency="ECB" conceptVersion="1.0" conceptRef="DATA_TYPE_FM"/>

     */
    var hiddenClass = '';

    var saxParser = XMLReaderFactory.createXMLReader();
    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        elements.push(localName);

        switch (localName) {
            case 'Header':
                s += '<h1>';
                break;
            case 'CodeList':
                id = atts.getValue(atts.getIndex('id'));
                s += '<ul class="listHeader">';
                s += '<li><strong>' + id + '</strong> - ';
                break;
            case 'CodeLists':
                s += '<h2>Code lists</h2>';
                break;
            case 'Concepts':
                s += '<h2>Concepts</h2><ul class="categorySchemeHidden">';
                break;
            case 'Concept':
                id = atts.getValue(atts.getIndex('id'));
                foundCount++;
                break;
            case 'Code':
                s += '<li><strong>' + atts.getValue(atts.getIndex('value')) + '</strong> - ';
                break;
            case 'Components':
                s += '<h2>Components</h2><ul>';
                break;
            case 'Dimension':
                //  <ns12:Dimension isFrequencyDimension="true" codelistAgency="ECB" codelist="CL_FREQ" conceptAgency="ECB" conceptVersion="1.0" conceptRef="FREQ"/>
                s += '<li>{0} - {1}{2}</li>'.format(atts.getValue(atts.getIndex('conceptRef')),
                        atts.getValue(atts.getIndex('codelist')),
                        (atts.getValue(atts.getIndex('isFrequencyDimension')) == 'true' ? ' <strong>Frequency Dimension</strong>' : '')
                        );
                break;
            case 'PrimaryMeasure':
                //  <ns12:PrimaryMeasure conceptAgency="ECB" conceptVersion="1.0" conceptRef="OBS_VALUE"/>
                s += '<p>Primary Measure - <strong>{0}</strong></p>'.format(atts.getValue(atts.getIndex('conceptRef')));
                break;
            case 'TimeDimension':
                // <ns12:TimeDimension conceptAgency="ECB" conceptVersion="1.0" conceptRef="TIME_PERIOD"/>
                s += '<p>Time Dimension - <strong>{0}</strong></p>'.format(atts.getValue(atts.getIndex('conceptRef')));
                break;
        }

    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        var leavingElement = elements.pop();
        switch (localName) {
            case 'Header':
                s += '</h1>';
                break;
            case 'CodeList':
                s += '</ul></ul>';
                foundCount++;
                break;
            case 'Concepts':
                s += '</ul>';
                break;
            case 'Code':
                s += '</li>';
                break;
            case 'Components':
                s += '</ul>';
                break;
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
        switch (currentName) {
            case 'Name':
                if (elements.indexOf('Header') > -1)
                {
                    s += ch;
                    return;
                }
                if (elements.indexOf('Concept') > -1)
                {
                    s += '<li><strong>' + id + '</strong> - ' + ch + '</li>';
                }
                if (elements.indexOf('CodeList') == elements.length - 2)// CodeList
                {
                    s += ' ' + ch + '</li><ul class="categorySchemeHidden">';
                    if (id.length > 0)
                        s += '<li>&nbsp;<a href="{0}?CodeList.html?objectid={1}">{1} details</a></li>'.format(getRpage(), ch);
                }
                id = '';
                break;
            case 'Code':
                s += ch + ' ';
                break;
            case 'Description':
                s += ch;
        }
    };

    saxParser.setHandler(contentHandler);
    saxParser.parseString(xmlhttp.responseText);

    if (foundCount == 0)
        s = '<p>No results found</p>';

    //console.log( s );
    div.innerHTML = s;
    dojo.byId("status").innerHTML = "Done";
    dojo.query(".listHeader").connect("onclick", expandCollapseLevel);
}

function call_codelist_ws() {
    dojo.byId('content').value = '';

    var id = dojo.byId('objectid').value;
    var soap = '<in><quer:And><quer:Codelist id="{0}"/><quer:AgencyID>ECB</quer:AgencyID></quer:And></in>'.format(id);

    call_ecb_sdmx_ws(soap, 'GetCodeList', 'content', getCodeListResponse);
}

function getCodelist(codeListId) {
    // processes the XML of a code list and returns an array of the codes and descriptions
    // code[id] = description
    // where the code is the array key
    var data = [];
    var soap = '<in><quer:And><quer:Codelist id="{0}"/><quer:AgencyID>ECB</quer:AgencyID></quer:And></in>'.format(codeListId);
    var localStorageKey = 'GetCodeList {0}'.format(codeListId);

    // see if the code list is already in local storage
    var v;

    try {
        v = localStorage[ localStorageKey ];
    } catch (e) {
    }

    if (v)
        return JSON.parse(v);

    function getCodeListResponseData(xmlhttp) {
        var contentHandler = new DefaultHandler2();
        var id = '', currentName = '';

        /*
         <ns4:CodeLists>
         <ns12:CodeList isFinal="true" version="1.0" agencyID="ECB" id="CL_BKN_ITEM">
         <ns12:Name>Banknote &amp; coin related items code list</ns12:Name>
         <ns12:Code value="A010">
         <ns12:Description>Number of ATM with a withdrawal function for euro banknotes (excluding devices with cash-depositing functionalities)</ns12:Description>
         </ns12:Code>
         <ns12:Code value="A020">
         <ns12:Description>Number of branches of Credit Institutions - Number of Credit Institutions and their branches providing cash services</ns12:Description>
         </ns12:Code
         ......
         </ns12:CodeList>
         </ns4:CodeLists>
         */

        var saxParser = XMLReaderFactory.createXMLReader();
        contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
            //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
            currentName = localName;
            if (localName == 'Code') {
                id = atts.getValue(atts.getIndex('value'));
            }
        };

        contentHandler.characters = function(ch, start, ch_length) {
            //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
            if (currentName == 'Description') {
                data.push({code: id, description: ch});
            }
        };

        saxParser.setHandler(contentHandler);
        saxParser.parseString(xmlhttp.responseText);
    }

    var xmlhttp = call_ecb_sdmx_ws_sync(soap, 'GetCodeList');
    getCodeListResponseData(xmlhttp);
    try {
        v = JSON.stringify(data);
        localStorage[ localStorageKey ] = v;
    }
    catch (e) {
        console.log('error on localStorage:' + e.message);
    }
    return data;
}

function getCodeListResponse(xmlhttp) {
    // processes the XML for all the category schemes
    dojo.byId("status").innerHTML = "Formatting results...";

    var div = dojo.byId('results');

    div.innerHTML = '';
    var s = '';
    var contentHandler = new DefaultHandler2();
    var id = '', description;
    var currentName = '';
    var foundCount = 0;
    var elements = Array();
    var data = [];

    /*
     <ns4:CodeLists>
     <ns12:CodeList isFinal="true" version="1.0" agencyID="ECB" id="CL_BKN_ITEM">
     <ns12:Name>Banknote &amp; coin related items code list</ns12:Name>
     <ns12:Code value="A010">
     <ns12:Description>Number of ATM with a withdrawal function for euro banknotes (excluding devices with cash-depositing functionalities)</ns12:Description>
     </ns12:Code>
     <ns12:Code value="A020">
     <ns12:Description>Number of branches of Credit Institutions - Number of Credit Institutions and their branches providing cash services</ns12:Description>
     </ns12:Code
     ......
     </ns12:CodeList>
     </ns4:CodeLists>
     */
    var hiddenClass = '';

    var saxParser = XMLReaderFactory.createXMLReader();
    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        elements.push(localName);

        switch (localName) {
            case 'Header':
                s += '<h1>';
                break;
            case 'Code':
                id = atts.getValue(atts.getIndex('value'));
                break;
        }
    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        var leavingElement = elements.pop();
        switch (localName) {
            case 'Header':
                s += '</h1><p/>';
                break;
            case 'CodeList':
                foundCount++;
                break;
            case 'Code':
                data.push({code: id, description: description});
                break;
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
        switch (currentName) {
            case 'Name':
                if (elements.indexOf('Header') > -1)
                {
                    s += ch;
                    return;
                }
                break;
            case 'Description':
                description = ch;
        }
    };

    saxParser.setHandler(contentHandler);
    saxParser.parseString(xmlhttp.responseText);

    if (foundCount == 0)
        s = '<p>No results found</p>';

    //console.log( s );
    var store = new dojo.store.Memory({data: data});
    grid.setStore(dojo.data.ObjectStore({objectStore: store}));
    div.innerHTML = s;
    dojo.byId("status").innerHTML = "Done";
}

function setup_codelist_grid() {
    grid = new dojox.grid.DataGrid({
        query: {code: "*"},
        structure: [
            {name: "Code", field: "code", width: "20%"},
            {name: "Description", field: "description", width: "60%"}
        ]
    }, "grid"
            );
    grid.startup();
}

function call_keyfamily_ws() {
    dojo.byId('content').value = '';

    var id = dojo.byId('objectid').value;
    var soap = '<in><quer:KeyFamily>' + id + '</quer:KeyFamily><quer:AgencyID>ECB</quer:AgencyID></in>';

    call_ecb_sdmx_ws(soap, 'GetKeyFamily', 'content', getKeyFamilyResponse);
}

function expandCollapseLevel(evt) {
    // method for handling expand and collapse of <li> elements
    // show all next hierachy level contained in this <ul> element
    var ul = this;
    var className = ul.className;

    var children = dojo.query('> ul', ul);
    console.log('expandCollapseLevel', className, children.length);
    for (z = 0; z < children.length; z++) {
        var c = children[z];
        c.classList.toggle('categorySchemeHidden');
    }
}

function getConceptResponse(xmlhttp) {
    // processes the XML for all the category schemes
    dojo.byId("status").innerHTML = "Formatting results...";

    var div = dojo.byId('results');

    div.innerHTML = '';
    var s = '';
    var contentHandler = new DefaultHandler2();
    var id = '';
    var currentName = '';
    var foundCount = 0;
    var elements = Array();

    /*
     <ns4:Header>
     <ns4:ID>5119b7c5-2b8d-409f-9695-f66a671f1711</ns4:ID><ns4:Test>false</ns4:Test><ns4:Prepared>2013-02-21T06:47:55+01:00</ns4:Prepared><ns4:Sender id="ECB"><ns4:Name>European Central Bank</ns4:Name><ns4:Contact><ns4:Email>statistics@ecb.europa.eu</ns4:Email></ns4:Contact></ns4:Sender>
     </ns4:Header>
     <ns4:Concepts>
     <ns12:Concept version="1.0" agencyID="ECB" id="FREQ">
     <ns12:Name>Frequency</ns12:Name>
     </ns12:Concept>
     <ns12:Concept version="1.0" agencyID="EUROSTAT" id="FREQ">
     <ns12:Name>Frequency</ns12:Name>
     </ns12:Concept>
     </ns4:Concepts>
     */
    var hiddenClass = '';

    var saxParser = XMLReaderFactory.createXMLReader();
    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        elements.push(localName);

        switch (localName) {
            case 'Header':
                s += '<h1>';
                break;
            case 'Concepts':
                s += '<table><tr><th>Agency</th><th>ID</th><th>Name</th></tr>';
                break;
            case 'Concept':
                id = atts.getValue(atts.getIndex('id'));
                foundCount++;
                s += '<tr><td>' + atts.getValue(atts.getIndex('agencyID')) + '</td><td>' + id + '</td><td>';
                break;
        }
    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        currentName = localName;
        var leavingElement = elements.pop();
        switch (localName) {
            case 'Header':
                s += '</h1>';
                break;
            case 'Concepts':
                s += '</table>';
                break;
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        //console.log( "characters : [" + ch + "], [" + start + "], [" + ch_length + "]" );
        switch (currentName) {
            case 'Name':
                if (elements.indexOf('Header') > -1)
                {
                    s += ch;
                    return;
                }
                if (elements.indexOf('Concept') > -1)
                {
                    s += ch + '</td></tr>';
                }
                break;
        }
    };
    try {
        saxParser.setHandler(contentHandler);
        saxParser.parseString(xmlhttp.responseText);
    } catch (e) {
        console.log('Problem processing response:' + e.message);
    }

    if (foundCount == 0)
    {
        s = '<p>No results found</p>';
    }
    //console.log( s );
    div.innerHTML = s;
    dojo.byId("status").innerHTML = "Done";
}

function call_concept_ws() {
    dojo.byId('content').value = '';

    var id = dojo.byId('objectid').value;
    var soap = '<in><quer:Concept>' + id + '</quer:Concept></in>';

    call_ecb_sdmx_ws(soap, 'GetConcept', 'content', getConceptResponse);
}

function storeJSON(key, j) {
    var s = JSON.stringify(j);
    if (s.length < 1000) {
        return;// don't store small stuff
    }

    var c = lzw_encode(s);
    console.log('compressed to {0} from {1}'.format(c.length, s.length));
    try {
        localStorage[key] = c;
    } catch (e) {
        console.log('storeJSON[{0}] error:{1}'.format(key, e.message));
        return false;
    }
    return true;
}

function recallJSON(key) {
    try {
        var c = localStorage[key];

        if (c) {
            var s = JSON.parse(lzw_decode(c));
            return s;
        }
    } catch (err) {
        console.log('error reading from localStorage' + err.message);
    }
    ;
    return null;
}

// LZW-compress a string
function lzw_encode(s) {
    var dict = {};
    var data = (s + "").split("");
    var out = [];
    var currChar;
    var phrase = data[0];
    var code = 256;
    for (var i = 1; i < data.length; i++) {
        currChar = data[i];
        if (dict[phrase + currChar] != null) {
            phrase += currChar;
        }
        else {
            out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
            dict[phrase + currChar] = code;
            code++;
            phrase = currChar;
        }
    }
    out.push(phrase.length > 1 ? dict[phrase] : phrase.charCodeAt(0));
    for (var i = 0; i < out.length; i++) {
        out[i] = String.fromCharCode(out[i]);
    }
    return out.join("");
}

// Decompress an LZW-encoded string
function lzw_decode(s) {
    var dict = {};
    var data = (s + "").split("");
    var currChar = data[0];
    var oldPhrase = currChar;
    var out = [currChar];
    var code = 256;
    var phrase;
    for (var i = 1; i < data.length; i++) {
        var currCode = data[i].charCodeAt(0);
        if (currCode < 256) {
            phrase = data[i];
        }
        else {
            phrase = dict[currCode] ? dict[currCode] : (oldPhrase + currChar);
        }
        out.push(phrase);
        currChar = phrase.charAt(0);
        dict[code] = oldPhrase + currChar;
        code++;
        oldPhrase = phrase;
    }
    return out.join("");
}

function gridFilter(options) {
    // search a dijit grid using the filter method
    // options:
    //   column - of the grid
    //   input - the field with the text in it.
    //   grid - the object of the grid
    var grid = options.grid;

    var filterText = options.input.value;
    var filter = {};

    if (filterText.length > 1) {
        filter[options.column] = '*{0}*'.format(filterText);
        grid.filter(filter, 1);
    }
    if (filterText.length < 1) {
        filter[options.column] = '*';
        grid.filter(filter, 1);
    }

}

// returns an array of country populations (1000s) indexed by ISO2 code
// ie: GB,IT
function getPopulation2010() {
    //CountryName,Sovereign,GEORegion,GEOSubregion,GEOID,ISO2Code,ISO3Code,UNCode,Developed,LeastDeveloped,OECD,SubSaharan,SmallIslandDev,ArabWorld,Population
    //Afghanistan,Afghanistan,Asia + Pacific,South Asia,4,AF,AFG,4,0,1,0,0,0,0,29117.5
    var iso2Pop = [];
    xmlhttp = new XMLHttpRequest();
    xmlhttp.open('GET', 'population2010.csv', false);
    xmlhttp.send();
    var lines = xmlhttp.responseText.split('\n');
    if (lines.length < 2) {
        throw('no data found in population');
    }
    var header = [];
    for (var count in lines) {
        var values = lines[count].split(',');
        if (count == 0) {
            header = values;
        }
        else
        {
            try {
                var iso2 = values[header.indexOf('ISO2Code')];
                var population = values[header.indexOf('Population')];
                var name = values[header.indexOf('CountryName')];
                iso2Pop[iso2] = {name: name, code: iso2, population: Number(population)};
            } catch (e) {
                console.log('getPopulation2010 error at {0}:{1}'.format(count, e.message));
            }
        }
    }
    return iso2Pop;
}

var globalPageMangler, globalProxy;

function getRpage() {
    var pageTypes = ['r.php', 'r.jsp'];
    var pageMangler;

    if (globalPageMangler)
    {
        return globalPageMangler;
    }
    else {
        for (p in pageTypes) {
            pageMangler = pageTypes[p];
            try {
                xmlhttp = new XMLHttpRequest();
                xmlhttp.open('HEAD', pageMangler + '?about.html', false);
                xmlhttp.send();
                globalPageMangler = pageMangler;
                return pageMangler;
            } catch (e) {
                console.log('Page mangler {0} not there:{1}'.format(pageMangler, e.message));
            }
        }
        throw('No page mangler found to open page {0}'.format(href));
    }
}

// finds out what r.php or h.jsp to use to open pages
function openPage(href, newWindow) {
    var pageMangler = getRpage();
    var url = '{0}?{1}'.format(pageMangler, href);
// use this one to open the link
    if (newWindow) {
        window.open(url, '_blank');
    } else {
        window.location = url;
    }
}

// finds out what r.php or h.jsp to use to open pages
function getProxyPage() {
    if (globalProxy)
        return globalProxy;

    var pageTypes = ['proxy.php', 'proxy.jsp'];

    for (p in pageTypes) {
        var proxy = pageTypes[p];
        try {
            xmlhttp = new XMLHttpRequest();
            xmlhttp.open('HEAD', proxy + '?about.html', false);
            xmlhttp.send();

            globalProxy = proxy;
            return proxy;
        } catch (e) {
            console.log('Proxy {0} not there:{1}'.format(proxy, e.message));
        }
    }
    throw('No proxy found');
}
