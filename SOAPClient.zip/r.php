<?php
  /***************************************************************************
   * USAGE
   * [1] r.php?pageName?token1=ABCDEFGH?token2=98734.......
   * 
   * REQUIREMENTS
   *     
   *  - Turn OFF magic quotes for incoming GET/POST data: add/modify the
   *    following line to your php.ini file:
   *     magic_quotes_gpc = Off 
   * 
   ***************************************************************************/
  
  $targetUrl = $_SERVER['QUERY_STRING'];
  if (!$targetUrl) {
    header('Status: 400', true, 400); // Bad Request
    echo 'Target URL is not specified! <br/> Usage: <br/> http://&lt;this-proxy-url&gt;?&lt;target-url&gt;';
    return;
  }
  // split by ? in the url
  //print "target url:$targetUrl\n";
  $parts = preg_split("/\?/", $targetUrl);
  $targetPath = $parts[0];

  $response = file_get_contents( $targetPath );
  
  // add the parameters to the page as #OPTION#
  //$imp = implode( ',', $parts );
  //print "parts=$imp\n";
  $x = 0;
  foreach ($parts as $value) {
	//print "$x value=$value\n";
	if( $x > 0 )
	{
		$bits = explode("=", $value);
		//print "#$bits[0]#=$bits[1]\n";
		$replaceString = "#$bits[0]#";
		$response = str_replace( $replaceString, $bits[1], $response );
	}
	$x++;
  }
  echo $response;
?>
