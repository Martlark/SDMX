// queries
// requires
dojo.require("dojox.charting.Chart");
dojo.require("dojox.charting.Chart2D");
dojo.require("dojox.charting.axis2d.Default");
dojo.require("dojox.charting.plot2d.Lines");
dojo.require("dojox.charting.widget.SelectableLegend");
dojo.require("dojox.charting.themes.Claro");
dojo.require('dojox.charting.action2d.Tooltip');
dojo.require("dojox.charting.action2d.Magnify");

var gridResults;
var sdmxData = {};
var queryOptions = {};

function parseQueryDataResponse(xmlhttp, breakValue) {
    /*
     <ns9:DataSet action="Replace" keyFamilyURI="http://sdw-ws.ecb.europa.eu/KeyFamily/ECB_EXR1">
     <ns9:KeyFamilyRef>ECB_EXR1</ns9:KeyFamilyRef>
     <ns9:Group type="Group">
     <ns9:GroupKey>
     <ns9:Value value="AUD" concept="CURRENCY"/>
     <ns9:Value value="EUR" concept="CURRENCY_DENOM"/>
     <ns9:Value value="SP00" concept="EXR_TYPE"/>
     <ns9:Value value="A" concept="EXR_SUFFIX"/>
     </ns9:GroupKey>
     <ns9:Attributes>
     <ns9:Value value="4" concept="DECIMALS"/>
     <ns9:Value value="0" concept="UNIT_MULT"/>
     <ns9:Value value="AUD" concept="UNIT"/>
     <ns9:Value value="ECB reference exchange rate, Australian dollar/Euro, 2:15 pm (C.E.T.)" concept="TITLE_COMPL"/>
     <ns9:Value value="4F0" concept="SOURCE_AGENCY"/>
     </ns9:Attributes>
     <ns9:Series>
     <ns9:SeriesKey>
     <ns9:Value value="Q" concept="FREQ"/>
     <ns9:Value value="AUD" concept="CURRENCY"/>
     <ns9:Value value="EUR" concept="CURRENCY_DENOM"/>
     <ns9:Value value="SP00" concept="EXR_TYPE"/>
     <ns9:Value value="A" concept="EXR_SUFFIX"/>
     </ns9:SeriesKey>
     <ns9:Attributes>
     <ns9:Value value="MOB.T0802" concept="PUBL_PUBLIC"/>
     <ns9:Value value="A" concept="COLLECTION"/>
     <ns9:Value value="P3M" concept="TIME_FORMAT"/>
     </ns9:Attributes>
     <ns9:Obs>
     <ns9:Time>1999-Q1</ns9:Time>
     <ns9:ObsValue value="1.7699"/>
     <ns9:Attributes>
     <ns9:Value value="A" concept="OBS_STATUS"/>
     </ns9:Attributes>
     </ns9:Obs>
     <ns9:Obs>
     <ns9:Time>1999-Q2</ns9:Time>
     <ns9:ObsValue value="1.618"/>
     <ns9:Attributes>
     <ns9:Value value="A" concept="OBS_STATUS"/>
     </ns9:Attributes>
     </ns9:Obs>

     */

    var contentHandler = new DefaultHandler2();
    var series_vals = {};
    var columns = ['Time', 'Value'];
    var column_descriptions = ['Time period', 'Observation Value'];
    var elements = [];
    var columnsFound = false;
    var time_period = '', obs_value = '', currentName, previousName, last_time_period = '';
    var latestData = []; // holds the last obeservation for each REF_AREA (breakField)

    var saxParser = XMLReaderFactory.createXMLReader();

    sdmxData = {};
    var data = [];
    sdmxData.data = data;

    contentHandler.startElement = function(namespaceURI, localName, qName, atts) {
        //console.log( "startElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        /*
         These are the query table column + OBS_VALUE
         <ns9:SeriesKey>
         <ns9:Value value="A" concept="FREQ"/>
         <ns9:Value value="I6" concept="REF_AREA"/>
         <ns9:Value value="N" concept="ADJUSTMENT"/>
         <ns9:Value value="5" concept="DATA_TYPE_BOP"/>
         <ns9:Value value="988D" concept="BOP_ITEM"/>
         <ns9:Value value="N" concept="CURR_BRKDWN"/>
         <ns9:Value value="A1" concept="COUNT_AREA"/>
         <ns9:Value value="E" concept="SERIES_DENOM"/>

         <ns9:Obs>
         <ns9:Time>1999-Q2</ns9:Time>
         <ns9:ObsValue value="1.618"/>
         <ns9:Attributes>
         <ns9:Value value="A" concept="OBS_STATUS"/>
         </ns9:Attributes>
         </ns9:Obs>

         <ns9:Attributes>
         <ns9:Value value="ECB reference exchange rate, Australian dollar/Euro, 2:15 pm (C.E.T.)"
         concept="TITLE_COMPL"/>
         */
        if (elements.length > 0)
            previousName = elements[elements.length - 1];
        currentName = localName;
        elements.push(localName);
        switch (localName) {
            case 'ObsValue':
                obs_value = atts.getValue(atts.getIndex('value'));
                break;
            case 'Obs':
                time_period = '';
                obs_value = '';
                break;
            case 'Value':
                if (!columnsFound) {
                    if ('Attributes' == previousName && elements.indexOf('Group') == elements.length - 3) {
                        if (atts.getValue(atts.getIndex('concept')) == 'TITLE_COMPL') {
                            column_descriptions.push(atts.getValue(atts.getIndex('value')));
                        }
                    }

                    if ('SeriesKey' == previousName && elements.indexOf('Series') == elements.length - 3) {
                        columns.push(atts.getValue(atts.getIndex('concept')));
                    }
                }
                if ('SeriesKey' == previousName && elements.indexOf('Series') == elements.length - 3) {
                    series_vals[atts.getValue(atts.getIndex('concept'))] = atts.getValue(atts.getIndex('value'));
                }
                break;
        }
    };
    contentHandler.endElement = function(namespaceURI, localName, qName) {
        //console.log( "endElement : [" + namespaceURI + "], [" + localName + "], [" + qName + "]" );
        elements.pop();
        switch (localName) {
            case 'SeriesKey':
                columnsFound = true;
                break;
            case 'Series':
                series_vals = {};
                vals = {};
                break;
            case 'Obs':
                // add the time and the observation value
                vals['Value'] = Number(obs_value);
                vals['Time'] = time_period;
                last_time_period = time_period;
                // add the series values to the data array
                for (z in series_vals) {
                    vals[z] = series_vals[z];
                }

                var latestDataFound = false;
                for (z in latestData) {
                    if (latestData[z][breakValue] == vals[breakValue]) {
                        latestDataFound = true;
                        latestData[z] = vals;
                        break;
                    }
                }
                if (!latestDataFound) {
                    latestData.push(vals);
                }
                data.push(vals);
                vals = {};
                break;
        }
    };
    contentHandler.characters = function(ch, start, ch_length) {
        switch (currentName) {
            case 'Time':
                if ('Obs' == previousName)
                    time_period = ch;
                break;
        }
    };

    dojo.byId('content').innerHTML = xmlhttp.responseText;
    try {
        saxParser.setHandler(contentHandler);
        saxParser.parseString(xmlhttp.responseText);
    } catch (e) {
        alert('Error parsing SDMX XML stream: {0}'.format(e.message));
        dojo.style(dojo.byId('content'), "display", "block");
        dojo.byId('content').focus();
    }
    sdmxData.data = data;
    sdmxData.latestData = latestData;
    sdmxData.columns = columns;
    sdmxData.column_descriptions = column_descriptions;
    sdmxData.timePeriods = [];
    // add all time periods so we can animate stuff
    for (var v in sdmxData.data) {
        if (sdmxData.timePeriods.indexOf(sdmxData.data[v].Time) == -1) {
            sdmxData.timePeriods.push(sdmxData.data[v].Time);
        }
    }
    return sdmxData;
}

function chartResultsBar(idLocation, breakValue, latestData) {
    // adds a chart to idLocation using
    // breakValue label, to be used when one row of observations per breakValue
    // data is an array of SDMX-ML object rows { Time, Value, SDMX_CONCEPTS, .... }
    var chart1 = new dojox.charting.Chart(idLocation);
    var labels = [];

    chart1.setTheme(dojox.charting.themes.Claro);
    chart1.addPlot("default", {type: "Columns", markers: true});

    var xLabelFunc = function(text, value, precision) {
        try {
            var label = labels[value - 1];
            //console.log( label, ':', text, value, precision );
            return label;
        }
        catch (err) {
            //console.log( 'xLabelFunc', err.message );
        }
        return null;
    };

    // add values for each column, one per breakValue
    var series = [], firstIndex = '';
    for (z in latestData) {
        //console.log( z );
        //console.log( latestData[z]);
        firstIndex = z;
        series.push(latestData[z].Value);
        labels.push(latestData[z][breakValue]);
    }

    chart1.addAxis("x",
            {labelFunc: xLabelFunc, majorLabels: true, minorLabels: true, gap: 5,
                title: '{0} - {1}'.format(breakValue, latestData[firstIndex].Time),
                titleOrientation: "away"
            });
    chart1.addAxis("y", {vertical: true, includeZero: true});
    //console.log( 'series', series );
    chart1.addSeries('bar', series);
    // Create the tooltip

    var tip = new dojox.charting.action2d.Tooltip(chart1, "default", {
        text: function(o) {
            return('{0}'.format(o.y));
        }
    });

    chart1.render();
}

function chartResults(idLocation, breakValue, data) {
    // adds a chart to idLocation and legend to idLocation+'Legend' using
    // breakValue as the value to split the series in data
    // data is an array of SDMX-ML object rows { Time, Value, SDMX_CONCEPTS, .... }
    var seriesCount = 0;
    var fillColors = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black'];

    var chart1 = new dojox.charting.Chart(idLocation);

    chart1.setTheme(dojox.charting.themes.Claro);
    chart1.addPlot("default", {type: dojox.charting.plot2d.Lines, markers: true});

    var xLabelFunc = function(text, value, precision) {
        try {
            var label = sdmxData.timePeriods[Number(text)];
            //console.log( label, ':', text, value, precision );
            return label;
        }
        catch (err) {
            //console.log( 'xLabelFunc', err.message );
            return '';
        }
    };

    chart1.addAxis("x", {title: "Time", titleOrientation: "away",
        labelFunc: xLabelFunc,
        majorLabels: true, majorTickStep: 4,
        includeZero: true});
    chart1.addAxis("y", {vertical: true, title: "Value", includeZero: true, majorTickStep: 4});

    // determine the by break series
    var series = [];
    var ref_area = ''; // the break for the series
    for (z in data) {
        var d = data[z][breakValue];

        if (ref_area == '')
            ref_area = d;

        if (ref_area != d) {
            chart1.addSeries(ref_area, series, {stroke: fillColors[seriesCount]});
            seriesCount++;
            if (seriesCount >= fillColors.length)
                seriesCount = 0;
            ref_area = d;
            series = [];
        }

        series.push(data[z].Value);
    }
    chart1.addSeries(ref_area, series, {stroke: fillColors[seriesCount]});
    // Create the tooltip
    new dojox.charting.action2d.Tooltip(chart1, "default", {
        text: function(o) {
            if (o.chart.series.length > 1)
                return ('{0}<br>{1}<br>{2}'.format(o.run.name, o.y, xLabelFunc(o.x)));
            else
                return ('{0}<br>{1}'.format(o.y, xLabelFunc(o.x)));

        }
    });
    // Highlights an area: use the "chart" chart, and "default" plot
    new dojox.charting.action2d.Highlight(chart1, "default");
    chart1.render();
    // http://dojo-toolkit.33424.n3.nabble.com/dojox-charting-wrong-size-when-chart-s-div-is-hidden-td2000025.html
    new dojox.charting.widget.SelectableLegend({chart: chart1, horizontal: true}, idLocation + "Legend");
}

function queryResultsCountDataPoints(breakValue, data) {
    // count the data points for the first breakValue series
    // to determine what chart to use.
    var dataPoints = 0;
    var ref_area = data[0][breakValue]; // the break for the series

    for (z in data) {
        var d = data[z][breakValue];

        if (ref_area != d) {
            return dataPoints;
        }

        dataPoints++;
    }
    return dataPoints;
}

function queryResultsResponse(xmlhttp, query) {
    // if the xmlhttp is a XMLHttpRequest object then parse the result
    // otherwise it is probably a stored data object.
    var breakField = decodeURIComponent(dojo.byId('break').value);

    if (xmlhttp.responseText) {
        sdmxData = parseQueryDataResponse(xmlhttp, breakField);
        // save the results of query to localStorage
        if (query) {
            k = JSON.stringify(query);
            storeJSON(k, sdmxData);
        }
    }
    else {
        sdmxData = xmlhttp; // read from localStorage
    }

    dojo.style(dojo.byId('executing'), "display", "none");
    dojo.style(dojo.byId('tabMain'), "display", "none");

    if (!sdmxData || !sdmxData.data || sdmxData.data.length == 0) {
        alert('No results found');
        return;
    }
    // http://dojo-toolkit.33424.n3.nabble.com/how-to-change-ItemFileWriteStore-data-or-dojox-grid-DataGrid-td2353208.html

    var storeItems = JSON.parse(JSON.stringify(sdmxData.data)); // clone the data as the setStore on the grid changes the original data.
    var store = new dojo.data.ItemFileWriteStore({data: {items: storeItems}});

    var structure = [];

    for (i in sdmxData.columns) {
        structure.push({name: sdmxData.columns[i], field: sdmxData.columns[i], width: '10%'});
    }
    gridResults = new dojox.grid.DataGrid({structure: structure}, "queryResultsGrid");
    gridResults.startup();

    gridResults.setStore(store);
    if (queryResultsCountDataPoints(breakField, sdmxData.data) == 1 || queryOptions.latestData)
        chartResultsBar("resultsChart", breakField, sdmxData.latestData);
    else
        chartResults("resultsChart", breakField, sdmxData.data);
}

function queryResultsInit() {
    //  calls the response functions and web service
    var query = JSON.parse(decodeURIComponent(dojo.byId('query').value));

    try {
        queryOptions = JSON.parse(decodeURIComponent(dojo.byId('options').value));
    } catch (e) {
    }
    ;
    var title = decodeURIComponent(dojo.byId('title').value);

    dojo.byId('h1Title').innerHTML = title;
    dojo.byId('headTitle').innerHTML = title;
    // see if a result for this
    var k = JSON.stringify(query), z;

    z = recallJSON(k);

    if (z)
    {
        console.log('reading query from local storage');
        sdmxData = z;
        queryResultsResponse(sdmxData);
    }
    else {
        var soap = build_dataflow_soap(query);
        if (soap)
            call_ecb_sdmx_ws(soap, 'GetGenericData', 'dataResults', queryResultsResponse, query);
    }
}

function build_dataflow_soap(query) {
    // builds a soap packet from the query
    /*
     query.qAnd = [];
     query.qOr = [];
     query.startTime = '';
     query.endTime = '';
     query.dataSetId = dojo.byId( 'objectid' ).value;
     */
    // go through constraints finding all checked and the start and end time.
    // first the AND
    // then time
    // following dataflow id
    // and finally all the OR things
    var soap = '<query><quer:And>';

    // Returns query results from the array that match the given query
    var constraintsAdded = 0;

    var i;
    for (i = 0; i < query.qAnd.length; i++) {
        var item = query.qAnd[i];
        soap += '<quer:Dimension id="{0}">{1}</quer:Dimension>'.format(
                item.component,
                item.value);
        constraintsAdded++;
    }

    if (query.startTime.length > 0 && query.endTime.length > 0)
    {
        soap += '<quer:Time>';
        soap += '<quer:StartTime>{0}</quer:StartTime>'.format(query.startTime);
        soap += '<quer:EndTime>{0}</quer:EndTime>'.format(query.endTime);
        soap += '</quer:Time>';
    }
    soap += '<quer:Dataflow>{0}</quer:Dataflow>'.format(query.dataSetId);
    if (query.qOr.length > 0) {
        soap += '<quer:Or>';
        for (i = 0; i < query.qOr.length; i++) {
            var item = query.qOr[i];
            soap += '<quer:Dimension id="{0}">{1}</quer:Dimension>'.format(
                    item.component,
                    item.value);
            constraintsAdded++;
        }
        soap += '</quer:Or>';
    }
    soap += '</quer:And></query>';
    if (constraintsAdded == 0)
    {
        alert('No query constraints found');
        return null;
    }
    return soap;
}
